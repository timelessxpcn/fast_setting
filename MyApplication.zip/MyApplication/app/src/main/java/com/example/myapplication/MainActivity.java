package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    // 存放数据，往ListViewer里面加
    private List<String> list = null;
    //记录服务器上有多少条设置信息
    Integer settingItemCnt = 0;
    private static final String[] strs = new String[] {
            "first", "second", "third", "fourth", "fifth"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        /* 按键部分 */
        // 参考连接：https://blog.csdn.net/zbw1185/article/details/94412673
        final Button btn_apply = (Button) findViewById(R.id.btn_apply);
        final Button btn_back = (Button) findViewById(R.id.btn_back);
        final ListView lv_setting = (ListView) findViewById(R.id.lv);
        list = new ArrayList<String>();

        list.add("设置1：\nWifi:开\t 闹钟:关\t");
        list.add("设置2：\n壁纸设置:开\t 闹钟:关\t");
        list.add("设置3：\n呼叫转移:开\t 闹钟:开\t");
        list.add("设置4：\n应用多开:开\t 闹钟:关\t");

        // 应用设置按键按下
        btn_apply.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (v.getId() == R.id.btn_apply) {
                    if (event.getAction() == MotionEvent.ACTION_DOWN) {
                        Log.v("btn_apply listener", "btn_apply is pressed!");
                    }
                }
                return false;
            }
        });

        // 返回按键按下
        btn_back.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                // 应用设置按键按下
                if (v.getId() == R.id.btn_back) {
                    if (event.getAction() == MotionEvent.ACTION_DOWN) {
                        Log.v("btn_back listener", "btn_back is pressed!");
                    }
                }
                return false;
            }
        });

        /* 网络部分 */
        // 参考连接：https://blog.csdn.net/iteye_5282/article/details/82329263?ops_request_misc=%257B%2522request%255Fid%2522%253A%2522163612593316780271558416%2522%252C%2522scm%2522%253A%252220140713.130102334..%2522%257D&request_id=163612593316780271558416&biz_id=0&utm_medium=distribute.pc_search_result.none-task-blog-2~all~sobaiduend~default-2-82329263.first_rank_v2_pc_rank_v29&utm_term=android+HttpURLConnection
        String httpUrl = "xxx";
        String resultData = "";
        URL url = null;
        try {
            url = new URL(httpUrl);
        } catch (MalformedURLException e) {
            Log.v("http", "MalformedURLException");
        }

        if (url != null) {
            try {
                // 使用HttpURLConnection打开连接
                HttpURLConnection urlConn = (HttpURLConnection) url.openConnection();
                // 得到读取的内容(流)
                InputStreamReader in = new InputStreamReader(urlConn.getInputStream());
                // 为输出创建BufferedReader
                BufferedReader buffer = new BufferedReader(in);
                String inputLine = null;
                //使用循环来读取获得的数据
                while (((inputLine = buffer.readLine()) != null)) {
                    //我们在每一行后面加上一个"\n"来换行
                    //resultData += inputLine + "\n";
                    list.add(inputLine);
                    settingItemCnt++;
                }
                if (!resultData.equals("")) {
                    // 在ListView上做操作。
                }
                //关闭InputStreamReader
                in.close();
                //关闭http连接
                urlConn.disconnect();
            } catch (IOException e) {
                Log.v("http", "IOException");
            }
        } else {
            Log.v("http", "Url NULL");
        }


        /* ListView部分 */
        // 参考连接：https://blog.csdn.net/kai_zone/article/details/80170963
        lv_setting.setAdapter(new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1,list ));

        // 选中对应设置item后的点击事件

        lv_setting.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String clickedSetting = list.get(position);
                Log.v("onItemClick", clickedSetting);
            }
        });
    }
}